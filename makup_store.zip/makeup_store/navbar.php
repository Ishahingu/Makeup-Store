
<nav style="background-color: #f8f8f8; padding: 10px;">
    <a href="index.php">Home</a> |
    <a href="cart.php">Cart</a> |
    <a href="my_orders.php">My Orders</a> |
    <a href="login.php">Login</a> |
    <a href="register.php">Register</a>
    <form action="index.php" method="GET" class="inline">
    <input type="text" name="search" placeholder="Search products" class="px-3 py-1 border rounded-full focus:outline-none focus:ring-2 focus:ring-pink-400">
    <button type="submit" class="bg-pink-500 text-white px-3 py-1 rounded-full ml-2 hover:bg-pink-600">Search</button>
</form>

</nav>
