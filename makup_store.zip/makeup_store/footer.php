
<hr>
<footer>
    <p style="text-align:center;">&copy; 2025 Makeup Store. All Rights Reserved.</p>
</footer>
